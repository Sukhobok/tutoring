********************************************************

  Mashshare I18n
  ============================
  
  Do not put custom translations here. They will be deleted
  on Mashshare updates.
  
  Keep custom MASHSB translations in /wp-content/languages/mashsb/
  
  You want to translate, help, or improve a translation?
  Write: info@mashshare.net or help us at https://www.transifex.com/projects/p/mashshare/

  More info at https://www.mashshare.net/

********************************************************
