#  Mashshare I18n #

  To help translate, review, or improve a translation, write Rene Hermenau at info@mashshare.net

  More info at https://www.mashshare.net/

# Quick Start #

    In mashsharer/languages/ you find a file named mashsb.po

    - Open it with the free editor: http://poedit.net/

    - Translate the strings and save it. Poedit automatically creates the file mashsb.mo

    - Rename this to your language specific translation. E.g. for italy the file is called mashsb-it_IT.mo and put it into the folder /mashsharer/languages/

I really appreciate it if you like to send me the generated mo file. I will put it than into the official Mashshare Plugin repository.

