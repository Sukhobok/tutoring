<?php
/**
 * Content wrappers
 *
 * @author 		spacex
 * @package 	xcourse/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>


<div itemscope class="course-content">
	
    <div class="container">
    
    <div class="course-page-content col-lg-12">     