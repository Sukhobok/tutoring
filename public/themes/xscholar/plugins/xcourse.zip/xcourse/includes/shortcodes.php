<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

include_once('shortcodes/courses.php' );
include_once('shortcodes/instructors.php' );