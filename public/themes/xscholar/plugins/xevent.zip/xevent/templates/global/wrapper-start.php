<?php
/**
 * Content wrappers
 *
 * @author 		spacex
 * @package 	xevent/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>


<div itemscope class="event-content">
	
    <div class="container">
    
    <div class="event-page-content col-lg-12">     