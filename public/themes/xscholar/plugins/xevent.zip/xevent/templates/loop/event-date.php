<?php
/**
 * Loop Thumbnaul
 *
 *
 * @author 		spacex
 * @package 	spacex/Templates
 * @version     1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


	?>