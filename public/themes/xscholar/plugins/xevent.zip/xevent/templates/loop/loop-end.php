<?php
/**
 * Course Loop End
 *
 * @author 		spacex
 * @package 	xevent/loop
 * @version     1.0.0
 */?>
</ul>
