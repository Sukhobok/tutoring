<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

include_once('shortcodes/xevents.php' );
include_once('shortcodes/speakers.php' );