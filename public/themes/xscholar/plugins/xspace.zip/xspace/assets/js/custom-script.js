(function( $ ) {
 
    // Add Color Picker to all inputs that have 'color-field' class
    $(function() {
        $('.cpx-color-picker').wpColorPicker();
    });
     
})( jQuery );